package com.cipher.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(13, 16, 23);
    private static final int PANEL = Color.rgb(24, 29, 40);
    private static final int ACCENT = Color.rgb(112, 145, 255);
    private static final String SYSTEM = "Ты — Cipher, лаконичный технический помощник. Отвечай на русском, структурированно и точно. Не выполняй запросы, которые могут привести к реальному вреду; для безопасных задач давай практичные объяснения.";
    private LinearLayout root, messages;
    private EditText input;
    private TextView status;
    private SharedPreferences prefs;
    private JSONArray history = new JSONArray();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("cipher", MODE_PRIVATE);
        try { String saved=prefs.getString("history","[]"); history=new JSONArray(saved); } catch(Exception ignored) {}
        showChat();
        addMessage("Cipher", "Система готова. Укажи API-ключ и модель в настройках, чтобы включить ответы ИИ.");
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(14, 10, 14, 10); return t;
    }
    private void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8, 10, 8, 10); bar.setBackgroundColor(PANEL);
        TextView name = text(title, 21, Color.WHITE); name.setTypeface(null, Typeface.BOLD);
        bar.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = new Button(this); settings.setText("Настройки"); settings.setOnClickListener(v -> showSettings());
        bar.addView(settings); root.addView(bar);
    }
    private void showChat() {
        base("CIPHER");
        status = text("Локальный интерфейс · API не подключён", 12, 0xffaab4c8); root.addView(status);
        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(8,8,8,8);
        scroll.addView(messages); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom = new LinearLayout(this); bottom.setPadding(8,8,8,8); bottom.setBackgroundColor(PANEL);
        input = new EditText(this); input.setSingleLine(false); input.setHint("Сообщение…"); input.setTextColor(Color.WHITE); input.setHintTextColor(0xff9aa4b5);
        bottom.addView(input, new LinearLayout.LayoutParams(0,-2,1));
        Button send = new Button(this); send.setText("Отправить"); send.setOnClickListener(v -> sendMessage());
        bottom.addView(send); root.addView(bottom);
        if (history.length() > 0) {
            for (int i=0;i<history.length();i++) {
                JSONObject m=history.optJSONObject(i);
                if(m!=null) addMessage(m.optString("role").equals("user")?"Вы":"Cipher",m.optString("content"));
            }
        }
    }
    private void addMessage(String who, String body) {
        TextView bubble = text(who + "\n" + body, 15, Color.WHITE);
        bubble.setBackgroundColor(who.equals("Вы") ? 0xff293653 : PANEL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(4,5,4,5);
        messages.addView(bubble,lp);
    }
    private void sendMessage() {
        String msg=input.getText().toString().trim(); if(msg.isEmpty()) return;
        input.setText(""); ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        try { history.put(new JSONObject().put("role","user").put("content",msg)); } catch(Exception ignored){}
        addMessage("Вы",msg);
        if(prefs.getString("key","").isEmpty()) {
            addMessage("Cipher","Сначала добавь API-ключ в настройках.");
            return;
        }
        status.setText("Запрос выполняется…");
        new Thread(() -> {
            String answer;
            try { answer = requestAI(); }
            catch(Exception e) { answer = "Ошибка запроса: " + e.getMessage(); }
            final String result=answer;
            runOnUiThread(() -> {
                addMessage("Cipher",result);
                try { history.put(new JSONObject().put("role","assistant").put("content",result)); } catch(Exception ignored){}
                prefs.edit().putString("history",history.toString()).apply();
                status.setText("Подключение настроено");
            });
        }).start();
    }
    private String requestAI() throws Exception {
        String endpoint=prefs.getString("endpoint","https://api.openai.com/v1/chat/completions");
        String model=prefs.getString("model","gpt-4o-mini");
        JSONArray msgs=new JSONArray().put(new JSONObject().put("role","system").put("content",SYSTEM));
        for(int i=0;i<history.length();i++) msgs.put(history.getJSONObject(i));
        JSONObject payload=new JSONObject().put("model",model).put("messages",msgs);
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json");
        c.setRequestProperty("Authorization","Bearer "+prefs.getString("key",""));
        try(OutputStream os=c.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode(); InputStream stream=code<400?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
        while((n=stream.read(buf))>0) out.write(buf,0,n);
        c.disconnect(); JSONObject response=new JSONObject(out.toString("UTF-8"));
        if(code>=400) throw new Exception(response.optJSONObject("error")!=null?response.getJSONObject("error").optString("message","HTTP "+code):"HTTP "+code);
        return response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","Пустой ответ");
    }
    private void showSettings() {
        base("НАСТРОЙКИ");
        ScrollView sc=new ScrollView(this); LinearLayout form=new LinearLayout(this); form.setPadding(16,12,16,12); form.setOrientation(LinearLayout.VERTICAL);
        sc.addView(form); root.addView(sc);
        form.addView(text("API endpoint",14,Color.WHITE));
        EditText endpoint=field(prefs.getString("endpoint","https://api.openai.com/v1/chat/completions"),false); form.addView(endpoint);
        form.addView(text("Модель",14,Color.WHITE));
        EditText model=field(prefs.getString("model","gpt-4o-mini"),false); form.addView(model);
        form.addView(text("API-ключ",14,Color.WHITE));
        EditText key=field(prefs.getString("key",""),true); form.addView(key);
        TextView note=text("Ключ хранится локально в настройках приложения. Не передавай его другим людям. Для OpenAI используй свой API-ключ; подписка ChatGPT не включает API-доступ.",13,0xffaab4c8);
        form.addView(note);
        Button save=new Button(this); save.setText("Сохранить настройки"); save.setOnClickListener(v->{
            prefs.edit().putString("endpoint",endpoint.getText().toString().trim())
                .putString("model",model.getText().toString().trim())
                .putString("key",key.getText().toString().trim()).apply();
            Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show(); showChat();
        }); form.addView(save);
        Button clear=new Button(this); clear.setText("Очистить историю"); clear.setOnClickListener(v->{
            history=new JSONArray(); prefs.edit().remove("history").apply(); Toast.makeText(this,"История очищена",Toast.LENGTH_SHORT).show();
        }); form.addView(clear);
        Button back=new Button(this); back.setText("Назад в чат"); back.setOnClickListener(v->showChat()); form.addView(back);
    }
    private EditText field(String value, boolean secret) {
        EditText e=new EditText(this); e.setText(value); e.setTextColor(Color.WHITE); e.setHintTextColor(0xff9aa4b5);
        e.setSingleLine(true); e.setPadding(12,8,12,8); e.setBackgroundColor(PANEL);
        if(secret) e.setInputType(129); return e;
    }
}
